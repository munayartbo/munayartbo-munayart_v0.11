<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tu página web</title>
    <!-- Aquí puedes incluir tus estilos CSS y scripts JS -->
    <link rel="stylesheet" href="views/css/styles.css">
    <script src="views/js/script.js"></script>

    <style>
        header {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            z-index: 1000;

        }

        /* Asegúrate de que el contenido del cuerpo no quede oculto detrás del encabezado */
        main {
            margin-top: 120px;
            /* Ajusta este valor según la altura del encabezado */
        }

        iframe {
            width: 100%;
            /*aspect-ratio: 16 / 9;*/
            border: none;
            overflow: hidden;
        }
    </style>
</head>

<body>
    <!-- =================================
           ENCABEZADO
        ================================== -->
    <header>
        <br>
        <iframe src="views/encabezado.php" scrolling="no" frameborder="0" style="width: 100%; height: 110px;"></iframe>
    </header>


    <!-- =================================
           CUERPO
        ================================== -->

    <main>
        <iframe id="contenido" src="views/inicio.php" frameborder="0" style="width: 100%;"
            ></iframe>
    </main>

    <!-- =================================
           FOOTER
        ================================== -->
    <footer>

        <div class="container">

            <div class="foo-row">
                <div class="foo-col">
                    <h2>Suscríbete <br>a nuestro newsletter</h2>
                    <form action="" method="GET">

                        <div class="f-input">
                            <input type="text" placeholder="Ingrese su correo">
                            <button type="submit" class="hm-btn-round btn-primary"><i
                                    class="far fa-paper-plane"></i></button>
                        </div>
                    </form>

                </div>

                <div class="foo-col">
                    <ul>
                        <li><a href="http://">Productos</a></li>
                        <li><a href="http://">Campañas</a></li>
                        <li><a href="http://">Nosotros</a></li>
                        <li><a href="http://">Contacto</a></li>
                        < </ul>
                </div>

            </div>

        </div>

    </footer>

    <div class="foo-copy">
        <div class="container">
            <p>MunayArt 2024 © Todos los derechos reservados</p>
        </div>
    </div>


    <!-- Aquí puedes incluir otros scripts al final del cuerpo -->

    <!-- Animaciones : AOS-->
    <script src="https://unpkg.com/aos@next/dist/aos.js"></script>

    <!-- Mi Script -->
    <script src="views/js/app.js"></script>

    <script>

        AOS.init({
            duration: 1200,
        })


    </script>

    <!-- Script para ajustar la altura del iframe según el contenido -->
    <script>
        // Escuchar mensajes del iframe
        window.addEventListener('message', function (event) {
            if (!isNaN(event.data)) {
                // Ajustar la altura del iframe según el mensaje recibido
                var iframe = document.getElementById('contenido');
                iframe.style.height = event.data + 'px';
            }
        });
    </script>

    <script>
        function ajustarAlturaIframe() {
            const iframe = document.getElementById('contenido');
            try {
                // Ajustar la altura del iframe al contenido cargado
                iframe.style.height = iframe.contentWindow.document.body.scrollHeight + 'px';
            } catch (error) {
                console.error("Error ajustando altura del iframe:", error);
            }
        }
    </script>


</body>

</html>