<?php
include 'db_connection.php';
session_start();

// Verifica si el usuario está autenticado
if (!isset($_SESSION['rol']) || $_SESSION['rol'] !== 'cliente') {
    echo "<script>
              alert('No tienes el rol de Cliente');
              window.location.href = '../views/loginIniReg.php';
          </script>";
    exit();
}

if (isset($_GET['CodPedido']) && isset($_GET['accion'])) {
    $codPedido = $_GET['CodPedido'];
    $accion = $_GET['accion'];

    // Establecer el nuevo estado dependiendo de la acción
    if ($accion == 'Cancelado') {
        $nuevoEstado = 'Cancelado';
    } elseif ($accion == 'Devolver') {
        $nuevoEstado = 'Devuelto'; // Cambia esto si tu estado es diferente
    } else {
        echo "<script>alert('Acción no válida.');</script>";
        exit();
    }

    // Actualiza el estado del pedido en la base de datos
    $sql = "UPDATE Pedido SET Estado = ? WHERE CodPedido = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("si", $nuevoEstado, $codPedido);

    // Verifica si el estado se actualiza correctamente
    if ($stmt->execute()) {
        // Si el nuevo estado es 'Aceptado', asigna un delivery (si es necesario)
        if ($nuevoEstado == 'Aceptado') {
            // Aquí debes agregar la lógica para asignar un delivery.
            // Por ejemplo, podrías elegir un delivery basado en tu lógica o consultar la base de datos.
            $codDelivery = 1; // Este valor debe provenir de tu lógica de asignación

            // Actualiza el campo CodDelivery en el pedido
            $sqlUpdateDelivery = "UPDATE Pedido SET CodDelivery = ? WHERE CodPedido = ?";
            $stmtDelivery = $conn->prepare($sqlUpdateDelivery);
            $stmtDelivery->bind_param("ii", $codDelivery, $codPedido);
            $stmtDelivery->execute(); // Ejecutar la actualización
        }

        echo "<script>
                  alert('Estado del pedido actualizado a $nuevoEstado.');
                  window.location.href = '../views/productos/vista_pedido_clientes.php'; // Redirige a la vista de pedidos
              </script>";
    } else {
        echo "<script>alert('Error al actualizar el estado del pedido.');</script>";
    }
} else {
    echo "<script>alert('Acción no válida.');</script>";
}
?>
