<?php
include 'db_connection.php';
session_start();

// Verificar que el usuario tenga el rol de delivery
if (!isset($_SESSION['rol']) || $_SESSION['rol'] !== 'delivery') {
    echo "<script>
              alert('No tienes el rol de Delivery');
              window.location.href = '../views/loginIniReg.php';
          </script>";
    exit();
}

// Obtener el ID del pedido y la acción desde la URL
if (isset($_GET['CodPedido']) && isset($_GET['accion'])) {
    $CodPedido = $_GET['CodPedido'];
    $accion = $_GET['accion'];

    // Obtener el ID del delivery de la sesión
    $CodDelivery = $_SESSION['user_id'];

    // Definir el nuevo estado según la acción
    if ($accion === 'Aceptar') {
        $nuevoEstado = 'Aceptado';
    } elseif ($accion === 'EnCamino') {
        $nuevoEstado = 'En Camino';
    } elseif ($accion === 'Entregar') {
        $nuevoEstado = 'Entregado';
    } elseif ($accion === 'Cancelar') {
        $nuevoEstado = 'Cancelado';
    } else {
        echo "<script>alert('Acción no válida.');</script>";
        exit();
    }

    // Actualizar el estado del pedido en la base de datos
    $sql = "UPDATE Pedido SET Estado = ? WHERE CodPedido = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("si", $nuevoEstado, $CodPedido);

    if ($stmt->execute()) {
        // Si la acción es 'Entregar', registrar la entrega
        if ($accion === 'Aceptar') {
            $horaEntrega = date('Y-m-d H:i:s'); // Obtener la fecha y hora actual
            $sqlEntrega = "INSERT INTO entrega (CodDelivery, CodPedido, Hora) VALUES (?, ?, ?)";
            $stmtEntrega = $conn->prepare($sqlEntrega);
            $stmtEntrega->bind_param("iis", $CodDelivery, $CodPedido, $horaEntrega);

            if ($stmtEntrega->execute()) {
                echo "<script>alert('Pedido registrado exitosamente.');</script>";
            } else {
                echo "<script>alert('Error al registrar la entrega.');</script>";
            }
        } else {
            echo "<script>alert('Estado del pedido actualizado a \"$nuevoEstado\" exitosamente.');</script>";
        }
    } else {
        echo "<script>alert('Error al actualizar el estado del pedido.');</script>";
    }

    echo "<script>window.location.href = '../views/productos/vista_pedido_delivery.php';</script>";
} else {
    echo "<script>alert('Parámetros inválidos.');</script>";
    echo "<script>window.location.href = '../views/productos/vista_pedido_delivery.php';</script>";
}
?>