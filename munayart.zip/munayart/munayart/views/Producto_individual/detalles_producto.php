<?php
session_start();
include '../../models/db_connection.php'; // Incluye la conexión a la base de datos

// Verificar si el usuario está logueado
if (!isset($_SESSION['user_id'])) {
    echo "Usuario no autenticado. Redirigiendo a la página de inicio...";
    header("Location: ../loginIniReg.php"); // Redirigir al login si no está autenticado
    exit();
}

// Obtener el CodProducto de la URL
$codProducto = $_GET['CodProducto'] ?? '';

if (!empty($codProducto)) {
    // Consulta para obtener detalles del producto
    $query = "SELECT * FROM producto pro 
              JOIN inventario inv ON pro.CodProducto = inv.CodProducto 
              WHERE pro.CodProducto = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $codProducto);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $producto = $result->fetch_assoc();

        // Nueva consulta: Obtener el promedio de las calificaciones y el total de reseñas
        $queryCalificacion = "SELECT ROUND(AVG(Calificacion), 1) AS promedio_calificacion, COUNT(*) AS total_resenias
                              FROM Resenia
                              WHERE CodProducto = ?";
        $stmtCalificacion = $conn->prepare($queryCalificacion);
        $stmtCalificacion->bind_param("i", $codProducto);
        $stmtCalificacion->execute();
        $resultCalificacion = $stmtCalificacion->get_result();

        if ($resultCalificacion->num_rows > 0) {
            $calificacionData = $resultCalificacion->fetch_assoc();
            $promedioCalificacion = $calificacionData['promedio_calificacion'];
            $totalResenias = $calificacionData['total_resenias'];
        }

        // Nueva consulta: reseñas de los productos
        $queryResenia = "SELECT u.Nombre, u.Apellido, r.Calificacion, r.Comentario, r.Fecha
                         FROM Resenia r
                         JOIN usuario u ON r.CodCliente = u.CodUsuario
                         WHERE r.CodProducto = ?";
        $stmtResenia = $conn->prepare($queryResenia);
        $stmtResenia->bind_param("i", $codProducto);
        $stmtResenia->execute();
        $resultResenia = $stmtResenia->get_result();

        // Verificar si hay reseñas
        $reseñas = [];
        if ($resultResenia->num_rows > 0) {
            while ($reseniaData = $resultResenia->fetch_assoc()) {
                $reseñas[] = $reseniaData; // Almacenar reseñas en un array
            }
        }

        // Cerrar las declaraciones
        $stmtCalificacion->close();
        $stmtResenia->close();
    } else {
        echo "Producto no encontrado.";
    }

    $stmt->close();
} else {
    echo "No se ha proporcionado un código de producto.";
}

$conn->close();
?>


<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <meta name="format-detection" content="telephone=no">
    <title>Producto Munayart</title>
    <link rel="icon" type="image/png" href="images/favicon.png"><!-- fonts -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:400,400i,500,500i,700,700i"><!-- css -->
    <link rel="stylesheet" href="vendor/bootstrap-4.2.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="vendor/owl-carousel-2.3.4/assets/owl.carousel.min.css">
    <link rel="stylesheet" href="css/style.css"><!-- js -->
    <script src="vendor/jquery-3.3.1/jquery.min.js"></script>
    <script src="vendor/bootstrap-4.2.1/js/bootstrap.bundle.min.js"></script>
    <script src="vendor/owl-carousel-2.3.4/owl.carousel.min.js"></script>
    <script src="vendor/nouislider-12.1.0/nouislider.min.js"></script>
    <script src="js/number.js"></script>
    <script src="js/main.js"></script>
    <script src="vendor/svg4everybody-2.1.9/svg4everybody.min.js"></script>
    <script>svg4everybody();</script><!-- font - fontawesome -->
    <link rel="stylesheet" href="vendor/fontawesome-5.6.1/css/all.min.css"><!-- font - stroyka -->
    <link rel="stylesheet" href="fonts/stroyka/stroyka.css">
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-97489509-6"></script>
    <script>window.dataLayer = window.dataLayer || []; function gtag() { dataLayer.push(arguments); } gtag('js', new Date()); gtag('config', 'UA-97489509-6');</script>
</head>

<body><!-- quickview-modal -->
    <header>
        <br>
        <iframe src="../encabezado2.php" scrolling="no" frameborder="0" style="width: 100%; height: 110px;"></iframe>
    </header>



    <!-- site -->
    <div class="site"><!-- mobile site__header -->


        <div class="site__body">

            <div class="block">
                <div class="container">
                    <div class="product product--layout--columnar" data-layout="columnar">
                        <div class="product__content">
                            <!-- .producto__galleria -->
                            <div class="product__gallery">
                                <div class="product-gallery">
                                    <!-- Imagen destacada con carousel -->
                                    <div class="product-gallery__featured">
                                        <div class="owl-carousel" id="product-image">
                                            <a href="../productos/<?php echo $producto['Imagen']; ?>" target="_blank">
                                                <img src="../productos/<?php echo $producto['Imagen']; ?>"
                                                    alt="<?php echo $producto['Nombre']; ?>">
                                            </a>
                                            <a href="../productos/<?php echo $producto['Imagen2']; ?>" target="_blank">
                                                <img src="../productos/<?php echo $producto['Imagen2']; ?>"
                                                    alt="<?php echo $producto['Nombre']; ?>">
                                            </a>
                                            <a href="../productos/<?php echo $producto['Imagen3']; ?>" target="_blank">
                                                <img src="../productos/<?php echo $producto['Imagen3']; ?>"
                                                    alt="<?php echo $producto['Nombre']; ?>">
                                            </a>
                                        </div>
                                    </div>
                                    <!-- Fin de imagen destacada -->
                                    <!-- Carrusel de miniaturas -->
                                    <div class="product-gallery__carousel">
                                        <div class="owl-carousel" id="product-carousel">
                                            <a href="#" class="product-gallery__carousel-item">
                                                <img class="product-gallery__carousel-image"
                                                    src="../productos/<?php echo $producto['Imagen']; ?>"
                                                    alt="<?php echo $producto['Nombre']; ?>">
                                            </a>
                                            <a href="#" class="product-gallery__carousel-item">
                                                <img class="product-gallery__carousel-image"
                                                    src="../productos/<?php echo $producto['Imagen2']; ?>"
                                                    alt="<?php echo $producto['Nombre']; ?>">
                                            </a>
                                            <a href="#" class="product-gallery__carousel-item">
                                                <img class="product-gallery__carousel-image"
                                                    src="../productos/<?php echo $producto['Imagen3']; ?>"
                                                    alt="<?php echo $producto['Nombre']; ?>">
                                            </a>
                                        </div>
                                    </div>
                                    <!-- Fin del carrusel de miniaturas -->
                                </div>
                            </div>
                            <!-- .producto__galleria / end -->

                            <!-- .producto__info -->

                            <div class="product__info">
                                <div class="product__wishlist-compare"><button type="button"
                                        class="btn btn-sm btn-light btn-svg-icon" data-toggle="tooltip"
                                        data-placement="right" title="Wishlist"><svg width="16px" height="16px">
                                            <use xlink:href="images/sprite.svg#wishlist-16"></use>
                                        </svg></button> <button type="button" class="btn btn-sm btn-light btn-svg-icon"
                                        data-toggle="tooltip" data-placement="right" title="Compare"><svg width="16px"
                                            height="16px">
                                            <use xlink:href="images/sprite.svg#compare-16"></use>
                                        </svg></button></div>

                                <?php echo " <h1 class='product__name'>" . $producto['Nombre'] . "</h1>"; ?>

                                <!--<div class="product__rating">
                                    <div class="product__rating-stars">
                                        <div class="rating">
                                            <div class="rating__body"><svg class="rating__star rating__star--active"
                                                    width="13px" height="12px">
                                                    <g class="rating__fill">
                                                        <use xlink:href="images/sprite.svg#star-normal"></use>
                                                    </g>
                                                    <g class="rating__stroke">
                                                        <use xlink:href="images/sprite.svg#star-normal-stroke"></use>
                                                    </g>
                                                </svg>
                                                <div class="rating__star rating__star--only-edge rating__star--active">
                                                    <div class="rating__fill">
                                                        <div class="fake-svg-icon"></div>
                                                    </div>
                                                    <div class="rating__stroke">
                                                        <div class="fake-svg-icon"></div>
                                                    </div>
                                                </div><svg class="rating__star rating__star--active" width="13px"
                                                    height="12px">
                                                    <g class="rating__fill">
                                                        <use xlink:href="images/sprite.svg#star-normal"></use>
                                                    </g>
                                                    <g class="rating__stroke">
                                                        <use xlink:href="images/sprite.svg#star-normal-stroke"></use>
                                                    </g>
                                                </svg>
                                                <div class="rating__star rating__star--only-edge rating__star--active">
                                                    <div class="rating__fill">
                                                        <div class="fake-svg-icon"></div>
                                                    </div>
                                                    <div class="rating__stroke">
                                                        <div class="fake-svg-icon"></div>
                                                    </div>
                                                </div><svg class="rating__star rating__star--active" width="13px"
                                                    height="12px">
                                                    <g class="rating__fill">
                                                        <use xlink:href="images/sprite.svg#star-normal"></use>
                                                    </g>
                                                    <g class="rating__stroke">
                                                        <use xlink:href="images/sprite.svg#star-normal-stroke"></use>
                                                    </g>
                                                </svg>
                                                <div class="rating__star rating__star--only-edge rating__star--active">
                                                    <div class="rating__fill">
                                                        <div class="fake-svg-icon"></div>
                                                    </div>
                                                    <div class="rating__stroke">
                                                        <div class="fake-svg-icon"></div>
                                                    </div>
                                                </div><svg class="rating__star rating__star--active" width="13px"
                                                    height="12px">
                                                    <g class="rating__fill">
                                                        <use xlink:href="images/sprite.svg#star-normal"></use>
                                                    </g>
                                                    <g class="rating__stroke">
                                                        <use xlink:href="images/sprite.svg#star-normal-stroke"></use>
                                                    </g>
                                                </svg>
                                                <div class="rating__star rating__star--only-edge rating__star--active">
                                                    <div class="rating__fill">
                                                        <div class="fake-svg-icon"></div>
                                                    </div>
                                                    <div class="rating__stroke">
                                                        <div class="fake-svg-icon"></div>
                                                    </div>
                                                </div><svg class="rating__star rating__star--active" width="13px"
                                                    height="12px">
                                                    <g class="rating__fill">
                                                        <use xlink:href="images/sprite.svg#star-normal"></use>
                                                    </g>
                                                    <g class="rating__stroke">
                                                        <use xlink:href="images/sprite.svg#star-normal-stroke"></use>
                                                    </g>
                                                </svg>
                                                <div class="rating__star rating__star--only-edge rating__star--active">
                                                    <div class="rating__fill">
                                                        <div class="fake-svg-icon"></div>
                                                    </div>
                                                    <div class="rating__stroke">
                                                        <div class="fake-svg-icon"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="product__rating-legend"><a href="#">7 Reviews</a><span>/</span><a
                                            href="#">Write A Review</a></div>
                                </div>-->

                                <!-- Estrellas BEGIN-->
                                <?php
                                // Mostrar calificación promedio y reseñas
                                echo "<div class='product__rating'>";
                                echo "<div class='product__rating-stars'>";
                                echo "<div class='rating'>";
                                echo "<div class='rating__body'>";

                                // Mostrar estrellas según el promedio
                                for ($i = 1; $i <= 5; $i++):
                                    if ($i <= $promedioCalificacion) {
                                        // Estrella completa
                                        echo "<svg class='rating__star rating__star--active' width='13px' height='12px'>
                                        <g class='rating__fill'>
                                            <use xlink:href='images/sprite.svg#star-normal'></use>
                                        </g>
                                        <g class='rating__stroke'>
                                            <use xlink:href='images/sprite.svg#star-normal-stroke'></use>
                                        </g>
                                    </svg>";
                                    } elseif ($i - 0.5 <= $promedioCalificacion) {
                                        // Media estrella
                                        echo "<svg class='rating__star rating__star--half-active' width='13px' height='12px'>
                                        <g class='rating__fill'>
                                            <use xlink:href='images/sprite.svg#star-half'></use>
                                        </g>
                                        <g class='rating__stroke'>
                                            <use xlink:href='images/sprite.svg#star-half-stroke'></use>
                                        </g>
                                    </svg>";
                                    } else {
                                        // Estrella vacía
                                        echo "<svg class='rating__star' width='13px' height='12px'>
                                        <g class='rating__fill'>
                                            <use xlink:href='images/sprite.svg#star-empty'></use>
                                        </g>
                                        <g class='rating__stroke'>
                                            <use xlink:href='images/sprite.svg#star-empty-stroke'></use>
                                        </g>
                                    </svg>";
                                    }
                                endfor;

                                echo "</div>"; // .rating__body
                                echo "</div>"; // .rating
                                echo "</div>"; // .product__rating-stars
                                
                                // Mostrar el número total de reseñas
                                echo "<div class='product__rating-legend'>
                                    <a href='#'>{$totalResenias} Reseñas</a>
                                    <span>/</span>
                                    <a href='#'>Escribe una reseña</a>
                                </div>";
                                echo "</div>"; // .product__rating
                                ?>

                                <!-- Estrellas End-->

                                <?php echo " <div class='product__description'>" . $producto['Descripcion'] . "</div>"; ?>

                                <ul class="product__features">
                                    <?php if (!empty($producto['Tipo'])): ?>
                                        <li>Tipo: <?php echo $producto['Tipo']; ?></li>
                                    <?php endif; ?>

                                    <?php if (!empty($producto['Material'])): ?>
                                        <li>Material: <?php echo $producto['Material']; ?></li>
                                    <?php endif; ?>

                                    <?php if (!empty($producto['Dimensiones'])): ?>
                                        <li>Dimensiones: <?php echo $producto['Dimensiones']; ?></li>
                                    <?php endif; ?>
                                </ul>

                                <ul class="product__meta">
                                    <li class="product__meta-availability">Disponibilidad: <span class="text-success">In
                                            Stock</span></li>
                                    <li>CodArtesano: <a href="#"><?php echo $producto['CodArtesano']; ?></li></a></li>
                                    <li>CodProducto: <?php echo $producto['CodProducto']; ?></li>
                                </ul>
                            </div><!-- .producto__info / end -->

                            <!-- .product__sidebar -->
                            <div class="product__sidebar">
                                <div class="product__availability">Disponibilidad:
                                    <?php if ($producto['Cantidad'] > 0): ?>
                                        <span class="text-success">
                                            En Stock: <?php echo $producto['Cantidad']; ?>
                                        </span>
                                    <?php else: ?>
                                        <span class="text-danger" style="color:red;">
                                            Agotado
                                        </span>
                                    <?php endif; ?>
                                </div>


                                <div class="product__prices">Bs. <?php echo $producto['Precio']; ?></div>
                                <!-- .product__options -->
                                <form class="product__options" id="form-producto" onsubmit="return false;">
                                    <div class="form-group product__option">
                                        <label class="product__option-label" for="product-quantity">Cantidad:</label>
                                        <div class="product__actions">
                                            <div class="product__actions-item">
                                                <div class="input-number product__quantity">
                                                    <input id="product-quantity"
                                                        class="input-number__input form-control form-control-lg"
                                                        type="number" min="1" value="1">
                                                    <div class="input-number__add"></div>
                                                    <div class="input-number__sub"></div>
                                                </div>
                                            </div>
                                            <div class="product__actions-item product__actions-item--addtocart">
                                                <!-- Información que necesitarás más tarde -->
                                                <div class="product-info"
                                                    data-codproducto="<?= $producto['CodProducto'] ?>"
                                                    data-nombre="<?= htmlspecialchars($producto['Nombre']) ?>"
                                                    data-imagen="<?= $producto['Imagen'] ?>">

                                                </div>

                                                <!-- Botón -->
                                                <button class="btn btn-primary btn-lg"
                                                    onclick="agregarAlCarrito(<?= $producto['CodProducto'] ?>, <?= $producto['Precio'] ?>)">
                                                    Añadir al carrito
                                                </button>
                                            </div>

                                            <!-- ... otros botones ... -->
                                        </div>
                                    </div>
                                </form>

                                <!-- .product__options / end -->
                            </div>
                            <!-- .product__end -->
                        </div>
                    </div>


                    <div class="product-tabs">
                        <div class="product-tabs__list">
                            <a href="#tab-reviews" class="product-tabs__item">Reseñas</a>
                        </div>
                        <div class="product-tabs__content">

                            <div class="product-tabs__pane" id="tab-reviews">
                                <div class="reviews-view">


                                    <div class="reviews-view__list">
                                        <h3 class="reviews-view__header">Comentarios de clientes</h3>
                                        <div class="reviews-list">
                                            <ol class="reviews-list__content">
                                                <?php if (!empty($reseñas)): ?>
                                                    <?php foreach ($reseñas as $reseniaData): ?>
                                                        <li class="reviews-list__item">
                                                            <div class="review">
                                                                <!--<div class="review__avatar">
                                                                    <img src="images/avatars/avatar-1.jpg" alt="">
                                                                    
                                                                </div>-->
                                                                <div class="review__content">
                                                                    <div class="review__author">
                                                                        <?= htmlspecialchars($reseniaData['Nombre'] . ' ' . $reseniaData['Apellido']) ?>
                                                                    </div>
                                                                    <div class="review__rating">
                                                                        <div class="rating">
                                                                            <div class="rating__body">
                                                                                <?php for ($i = 1; $i <= 5; $i++): ?>
                                                                                    <svg class="rating__star <?= ($i <= $reseniaData['Calificacion']) ? 'rating__star--active' : '' ?>"
                                                                                        width="13px" height="12px">
                                                                                        <g class="rating__fill">
                                                                                            <use
                                                                                                xlink:href="images/sprite.svg#star-normal">
                                                                                            </use>
                                                                                        </g>
                                                                                        <g class="rating__stroke">
                                                                                            <use
                                                                                                xlink:href="images/sprite.svg#star-normal-stroke">
                                                                                            </use>
                                                                                        </g>
                                                                                    </svg>
                                                                                <?php endfor; ?>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="review__text">
                                                                        <?= htmlspecialchars($reseniaData['Comentario']) ?>
                                                                    </div>
                                                                    <div class="review__date">
                                                                        <?= htmlspecialchars($reseniaData['Fecha']) ?>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </li>
                                                    <?php endforeach; ?>
                                                <?php else: ?>
                                                    <li class="reviews-list__item">
                                                        <p>No hay reseñas disponibles para este producto.</p>
                                                    </li>
                                                <?php endif; ?>
                                            </ol>
                                        </div>
                                    </div>




                                    <form class="reviews-view__form" id="reviewForm">
                                        <h3 class="reviews-view__header">Escribe una reseña</h3>
                                        <input type="hidden" name="codProducto"
                                            value="<?= htmlspecialchars($codProducto) ?>"> <!-- Código del producto -->
                                        <input type="hidden" name="codCliente" value="<?= $_SESSION['user_id'] ?>">
                                        <!-- Almacena el ID del usuario desde la sesión -->
                                        <div class="row">
                                            <div class="col-12 col-lg-9 col-xl-8">
                                                <div class="form-row">
                                                    <div class="form-group col-md-4">
                                                        <label for="review-stars">Calificación</label>
                                                        <select id="review-stars" class="form-control"
                                                            name="calificacion" required>
                                                            <option value="">Seleccione una calificación</option>
                                                            <option value="5">5 Stars Rating</option>
                                                            <option value="4">4 Stars Rating</option>
                                                            <option value="3">3 Stars Rating</option>
                                                            <option value="2">2 Stars Rating</option>
                                                            <option value="1">1 Stars Rating</option>
                                                        </select>
                                                    </div>
                                                    <div class="form-group col-md-4">
                                                        <label for="review-author">Usuario</label>
                                                        <input type="text" class="form-control" id="review-author"
                                                            name="usuario" placeholder="Usuario"
                                                            value="<?= htmlspecialchars($_SESSION['user_name']) ?>"
                                                            disabled>
                                                    </div>
                                                    <div class="form-group col-md-4">
                                                        <label for="review-email">Email</label>
                                                        <input type="email" class="form-control" id="review-email"
                                                            name="email" placeholder="Email"
                                                            value="<?= htmlspecialchars($_SESSION['user_email']) ?>"
                                                            disabled>
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label for="review-text">Comentario</label>
                                                    <textarea class="form-control" id="review-text" name="comentario"
                                                        rows="6" required></textarea>
                                                </div>
                                                <div class="form-group mb-0">
                                                    <button type="submit" class="btn btn-primary btn-lg">Enviar
                                                        Reseña</button>
                                                </div>
                                            </div>
                                        </div>
                                    </form>

                                    <script>
                                        document.getElementById("reviewForm").addEventListener("submit", function (event) {
                                            event.preventDefault(); // Evita que el formulario se envíe de la manera tradicional

                                            const formData = new FormData(this); // Captura los datos del formulario

                                            fetch("guardar_resenia.php", {
                                                method: "POST",
                                                body: formData,
                                            })
                                                .then(response => response.json())
                                                .then(data => {
                                                    if (data.status === "success") {
                                                        alert("Reseña guardada exitosamente"); // Muestra el mensaje
                                                        // Opcionalmente, puedes limpiar el formulario aquí
                                                        document.getElementById("reviewForm").reset(); // Reiniciar el formulario si lo deseas
                                                        window.location.href = window.location.href; // Recargar la misma página
                                                    } else {
                                                        alert("Error al guardar la reseña: " + data.message); // Muestra el error
                                                    }
                                                })
                                                .catch(error => {
                                                    console.error('Error:', error);
                                                    alert("Hubo un problema al enviar la reseña.");
                                                });
                                        });
                                    </script>







                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div><!-- site__body / end --><!-- site__footer -->
        <footer class="site__footer">
            <div class="site-footer">
                <div class="container">
                    <div class="site-footer__bottom">

                        <div class="site-footer__payments"><img src="images/payments.png" alt=""></div>
                    </div>
                </div>
            </div>
        </footer><!-- site__footer / end -->
    </div><!-- site / end -->

    <script src="../productos/js/carrito.js"></script>
</body>

</html>