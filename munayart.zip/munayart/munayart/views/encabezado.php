<?php
// Iniciar la sesión antes de cualquier salida de HTML
session_start();
//print_r($_SESSION)
    ?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>MunayArt</title>

    <!-- =================================
           PRINCIPAL
        ================================== -->

    <!-- FUENTE GOOGLE FONTS : Poppins -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600;700;800&display=swap"
        rel="stylesheet">

    <!-- ICONS: Font Awesome -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css">

    <!-- ICONS: Line Awesome -->
    <link rel="stylesheet"
        href="https://maxst.icons8.com/vue-static/landings/line-awesome/line-awesome/1.3.0/css/line-awesome.min.css">

    <!-- Animaciones AOS -->
    <link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css">


    <!-- Mis Estilos -->
    <link rel="stylesheet" href="css/styles.css">

    <!-- =================================
           BOTON MENU
        ================================== -->
    <!-- Estilos para el menú lateral -->
    <style>
        /* El contenedor del menú oculto */
        #menuHorizontal {
            display: none;
            /* Inicialmente oculto */
            position: absolute;
            /* Para que no afecte el flujo del documento */
            height: 40px;
            width: auto;
            top: 5px;
            /* Ajusta según la posición deseada */
            left: -700px;
            /* Ajusta según la posición deseada */
            background-color: #fff;
            /* Cambia el color de fondo según sea necesario */
            border-radius: 5px;
            padding: 0;
            white-space: nowrap;
            display: flex;
            /* Para permitir centrado */
            align-items: center;
            /* Para centrar verticalmente */
        }

        /* Links dentro del menú */
        #menuHorizontal a {
            padding: 5px 8px;
            /* Reduce el espaciado alrededor del texto */
            height: 40px;
            text-decoration: none;
            color: rgb(17, 14, 14);
            font-size: 16px;
            display: flex;
            align-items: center;
            transition: 0.3s;

        }

        /* Cambiar color al pasar el mouse sobre los enlaces */
        #menuHorizontal a:hover {
            background-color: #f17575;
            border-radius: 5px;
        }

        /*boton menu*/
        /* From Uiverse.io by gagan-gv */
        .btn {
            width: 150px;
            height: 50px;
            border-radius: 5px;
            border: none;
            transition: all 0.5s ease-in-out;
            font-size: 20px;
            font-family: Verdana, Geneva, Tahoma, sans-serif;
            font-weight: 600;
            display: flex;
            align-items: center;
            background: #040f16;
            color: #f5f5f5;
            margin-right: 0px;

        }

        .btn:hover {
            box-shadow: 0 0 20px 0px #2e2e2e3a;
        }

        .btn .icon {
            position: absolute;
            height: 40px;
            width: 70px;
            display: flex;
            justify-content: center;
            align-items: center;
            transition: all 0.5s;
        }

        .btn .text {
            transform: translateX(55px);
        }

        .btn:hover .icon {
            width: 175px;
        }

        .btn:hover .text {
            transition: all 0.5s;
            opacity: 0;
        }

        .btn:focus {
            outline: none;
        }

        .btn:active .icon {
            transform: scale(0.85);
        }




        /* Estilos para el encabezado */
        .header-container {
            display: flex;
            justify-content: space-between;
            /* Espacio entre el logo y el menú */
            align-items: center;
            /* Alinear verticalmente */
            padding: 0 20px;
            /* Espaciado lateral */
            height: 64px;
            /* Altura del contenedor del encabezado */
            background-color: #fff;
            /* Color de fondo */
        }

        /* Logo */
        .logo-container {
            display: flex;
            align-items: center;
            /* Centrar verticalmente el logo */
        }

        .logo-container img {
            max-height: 100px;
            max-width: 250px;
            height: auto;
            margin: 0;
            /* Remueve márgenes adicionales */
        }
    </style>

</head>

<body>


    <!-- =================================
           HEADER MENU
        ================================== -->


    <div class="header-container">
        <!-- Contenedor del logo -->
        <div class="logo-container">
            <a href="#">
                <img src="imagenes/LogoNombre.png" alt="Logo">
            </a>
            <?php
            // Comprobar si el usuario ha iniciado sesión
            if (isset($_SESSION['user_name'])) {
                $user_name = $_SESSION['user_name'];
                echo "<h3>¡Bienvenido! $user_name</h3>";
                echo "<a href='logout.php' target='_top'>Cerrar sesión</a>";  // Enlace para cerrar sesión
            } else {
                // Si no hay una sesión de usuario, redirigir al login
                echo "<h3>¡Bienvenido!</h3>";
            }
            ?>

        </div>




        <!-- Menú principal -->
        <nav class="hm-menu">
            <div id="main">
                <button class="btn" onclick="toggleMenu()">
                    <span class="icon">
                        <svg viewBox="0 0 175 80" width="40" height="40">
                            <rect width="80" height="15" fill="#f0f0f0" rx="10"></rect>
                            <rect y="30" width="80" height="15" fill="#f0f0f0" rx="10"></rect>
                            <rect y="60" width="80" height="15" fill="#f0f0f0" rx="10"></rect>
                        </svg>
                    </span>
                    <span class="text">MENU</span>
                </button>

                <div id="menuHorizontal">
                    <a href="#" onclick="cambiarContenido('views/inicio.php')">Inicio</a>
                    <a href="#" onclick="cambiarContenido('views/filtradoProc/filtradoProduct.php')">Productos</a>
                    <a href="subir_producto.php" target="_top">Artesano</a>
                    <!--<a href="completar_datos_delivery.php" target="_top">Delivery</a>-->
                    <a href="productos/vista_pedido_delivery.php" target="_top">Delivery</a>
                    <a href="productos/vista_pedido_clientes.php" target="_top">Pedido</a>
                    <a href="#" onclick="cambiarContenido('views/nosotros.php')">Nosotros</a>
                    <div class="login_menu">
                        <ul>
                            <li><a href="productos/carrito.php" target="_top">
                                    <i class="fa fa-shopping-cart" aria-hidden="true"></i>
                                    <span class="padding_10">Cart</span></a>
                            </li>
                            <li><a href="loginIniReg.php" target="_top">
                                    <i class="fa fa-user" aria-hidden="true"></i>
                                    <span class="padding_10">Login</span></a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </nav>
    </div>

    <!-- =================================
           HEADER MENU Movil
        ================================== -->
    <div class="header-menu-movil">
        <button class="cerrar-menu"><i class="fas fa-times"></i></button>
        <ul>
            <li><a href="#">Productos</a></li>
            <li><a href="#">Campañas</a></li>
            <li><a href="#">Nosotros</a></li>
            <li><a href="#">Contacto</a></li>
        </ul>
    </div>



    <!-- Animaciones : AOS-->
    <script src="https://unpkg.com/aos@next/dist/aos.js"></script>

    <!-- Mi Script -->
    <script src="js/app.js"></script>

    <script>

        AOS.init({
            duration: 1200,
        })


    </script>

    <!-- =================================
           BOTON MENU
        ================================== -->
    <!-- Scripts para funcionalidad del menú -->
    <script>
        // Aseguramos que el menú esté oculto cuando se carga la página
        window.onload = function () {
            document.getElementById("menuHorizontal").style.display = "none";
        };

        // Función para mostrar y ocultar el menú horizontal
        function toggleMenu() {
            var menu = document.getElementById("menuHorizontal");
            if (menu.style.display === "none" || menu.style.display === "") {
                menu.style.display = "flex"; // Muestra el menú
            } else {
                menu.style.display = "none";  // Oculta el menú
            }
        }
    </script>

    <script>
        // Envía un mensaje al documento padre (la página principal) para cambiar el contenido
        function cambiarContenido(pagina) {
            window.parent.postMessage({ pagina: pagina }, '*');
        }
    </script>

</body>

</html>