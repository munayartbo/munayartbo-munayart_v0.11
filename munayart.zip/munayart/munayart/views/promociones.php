<?php
include '../controllers/db_connection.php';

// Consultar promociones junto con las fechas
$sql_promociones = "SELECT Titulo, Descripcion, FechaInicio, FechaFin, Imagen 
                    FROM promocion";
$result_promociones = $conn->query($sql_promociones);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Promociones</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, Helvetica, sans-serif;
        }
        
        body {
            background-color: #F5F5F5;
        }
        
        .titulo {
            text-align: center;
            font-size: 40px;
            padding-top: 50px;
        }

        .slider-box {
            width: 600px;
            height: auto;
            margin: 30px auto 0;
            overflow: hidden;
        }
    
        .slider-box ul {
            display: flex;
            padding: 0;
            width: 400%;
            animation: slide 20s infinite alternate ease-in-out;
        }
        .slider-box li {
            width: 50%;
            list-style: none;
            position: relative;
        }
        .texto {
            position: absolute;
            text-align: center;
            padding: 0 150px;
            top: 260px;
            color: #000000;
        }
        .texto h2 {
            font-size: 25px;
            margin-bottom: 35px;
        }
        .slider-box img {
            width: 100%; 
            height: 50%; 
        }
    
        @keyframes slide {
            0% { margin-left: 0; }
            20% { margin-left: 0; }

            25% { margin-left: -100%; }
            45% { margin-left: -100%; }

            50% { margin-left: -200%; }
            70% { margin-left: -200%; } 

            75% { margin-left: -300%; }
            100% { margin-left: -300%; }
        }
        @media(max-width: 991px) {
            body {
                padding: 30px;
            }
            .slider-box {
                width: 100%;
            }
            .texto {
                top: 50px;
                padding: 0 25px;
            }
            .texto h2 {
                font-size: 35px;
                margin-bottom: 15px;
            }
            .texto p {
                font-size: 15px;
            }
        }

    </style>

</head>
<body>
    
    <div class="slider-box">
        <ul>
            <?php
            if ($result_promociones->num_rows > 0) {
                while ($row = $result_promociones->fetch_assoc()) {
                    echo '<li>';
                    echo '<img src="imagenes/' . $row['Imagen'] . '" alt="Imagen Promocion">';
                    echo '<div class="texto">';
                    echo '<h3>' . $row['Titulo'] . '</h3>';
                    echo '<p>' . $row['Descripcion'] . '</p>';
                    echo '<p><strong>Inicio:</strong> ' . date('d/m/Y', strtotime($row['FechaInicio'])) . '</p>';
                    echo '<p><strong>Fin:</strong> ' . date('d/m/Y', strtotime($row['FechaFin'])) . '</p>';
                    echo '</div>';
                    echo '</li>';
                }
            } else {
                echo "<li>No hay promociones disponibles</li>";
            }
            ?>
        </ul>
    </div>
    
</body>
</html>
