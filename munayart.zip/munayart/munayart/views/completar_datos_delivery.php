<?php
include '../controllers/db_connection.php';

// Verificar que el usuario tenga el rol de artesano
session_start();
if (!isset($_SESSION['rol']) || $_SESSION['rol'] !== 'delivery') {
    echo "<script>
              alert('No tienes el rol de Delivery');
              window.location.href = '../views/loginIniReg.php';
          </script>";
    exit();
}

// Obtener la lista de comunidades desde la base de datos
$sql_comunidades = "SELECT CodComunidad, Nombre FROM comunidad";
$result_comunidades = $conn->query($sql_comunidades);

// Verificar si hay comunidades disponibles
if ($result_comunidades->num_rows == 0) {
    echo "<script>
              alert('No hay comunidades disponibles. Contacta al administrador.');
              window.location.href = 'subir_producto.php';
          </script>";
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Completar Datos Artesano</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            color: #fff;
        }

        .container {
            background-color: #FFFFFF;
            border-radius: 15px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
            padding: 40px;
            max-width: 900px;
            width: 100%;
            text-align: center;
            position: relative;
        }

        h2 {
            color: #D64045;
            text-align: left;
        }

        form {
            margin-top: 20px;
        }

        label {
            font-size: 1.1em;
            margin-bottom: 5px;
            color: #333;
        }

        input[type="text"],
        input[type="number"],
        input[type="file"],
        select,
        textarea {
            width: 50%;
            padding: 10px;
            margin-bottom: 15px;
            border-radius: 5px;
            border: 1px solid #ccc;
            font-size: 1em;
        }

        button {
            background-color: #D64045;
            color: white;
            border: none;
            padding: 10px;
            width: 40%;
            border-radius: 5px;
            font-size: 1em;
            cursor: pointer;
            margin-top: 10px;
        }

        button:hover {
            background-color: #b52e37;
        }

        /* Estilos para el logo */
        .logo {
            position: absolute;
            top: 20px;
            left: 20px;
            width: 220px;
        }
    </style>
</head>
<body>
 <!-- Logo de MunayArt -->
 <a href="../index.php" class="logo"><img src="imagenes/LogoNombre.png" alt="Logo MunayArt" class="logo"></a>
    <div class="container">
        <h2>Completar Datos del Delivery</h2>
        <form action="../controllers/procesar_datos_delivery.php" method="POST" enctype="multipart/form-data">
            <label for="foto_perfil">Foto de perfil:</label>
            <input type="file" id="foto_perfil" name="foto_perfil" accept="image/*" required><br>

            <label for="tipo_vehiculo">Tipo de vehículo:</label>
            <input type="text" id="tipo_vehiculo" name="tipo_vehiculo" required><br>

            <label for="placa">Placa del vehículo:</label>
            <input type="text" id="placa" name="placa" required><br>

            <label for="cod_departamento">Departamento:</label>
            <select name="cod_departamento" id="cod_departamento" required><br>
                <option value="">Seleccione un departamento</option>
                <option value="1">La Paz</option>
                <option value="2">Cochabamba</option>
                <option value="3">Santa Cruz</option>
                <option value="4">Oruro</option>
                <option value="5">Potosí</option>
                <option value="6">Tarija</option>
                <option value="7">Beni</option>
                <option value="8">Pando</option>
                <option value="9">Chuquisaca</option>
            </select>

            <label for="hora_ingreso">Hora de ingreso:</label>
            <input type="time" id="hora_ingreso" name="hora_ingreso" required><br>

            <label for="hora_salida">Hora de salida:</label>
            <input type="time" id="hora_salida" name="hora_salida" required><br>

            <button type="submit">Guardar Datos</button>
        </form>
    </div>
</body>
</html>

<?php
// Cerrar conexión
$conn->close();
?>
